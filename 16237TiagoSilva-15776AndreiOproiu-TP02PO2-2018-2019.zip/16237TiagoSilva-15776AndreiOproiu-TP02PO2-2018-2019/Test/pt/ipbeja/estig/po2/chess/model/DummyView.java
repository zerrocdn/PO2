package pt.ipbeja.estig.po2.chess.model;

import pt.ipbeja.estig.po2.chess.gui.View;

import java.util.List;

public class DummyView implements View {
    @Override
    public void markPossibleMoves(List<Position> moves) {


    }

    @Override
    public void markPossibleTakes(List<Position> takes) {

    }

    @Override
    public void resetButtonsBackground() {

    }

    @Override
    public void updateHistory(String text) {

    }
}
